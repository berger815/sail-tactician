import test from "node:test";
import assert from "node:assert/strict";
import {
  normalizeDegrees,
  angleDifference,
  absoluteAngleDifference
} from "../src/domain/navigation/angles.js";

test("normalizeDegrees wraps values", () => {
  assert.equal(normalizeDegrees(370), 10);
  assert.equal(normalizeDegrees(-10), 350);
});

test("angleDifference crosses north correctly", () => {
  assert.equal(angleDifference(350, 10), 20);
  assert.equal(angleDifference(10, 350), -20);
});

test("absoluteAngleDifference returns shortest separation", () => {
  assert.equal(absoluteAngleDifference(355, 5), 10);
});
