import test from "node:test";
import assert from "node:assert/strict";
import { classifyLeg } from "../src/domain/sailing/legs.js";

test("classifies mark toward wind as upwind", () => {
  assert.equal(
    classifyLeg({
      trueWindDirection: 0,
      markBearing: 20
    }),
    "upwind"
  );
});

test("classifies mark away from wind as downwind", () => {
  assert.equal(
    classifyLeg({
      trueWindDirection: 0,
      markBearing: 180
    }),
    "downwind"
  );
});

test("classifies beamward mark as reach", () => {
  assert.equal(
    classifyLeg({
      trueWindDirection: 0,
      markBearing: 90
    }),
    "reach"
  );
});

test("returns unknown for missing input", () => {
  assert.equal(
    classifyLeg({
      trueWindDirection: null,
      markBearing: 90
    }),
    "unknown"
  );
});
