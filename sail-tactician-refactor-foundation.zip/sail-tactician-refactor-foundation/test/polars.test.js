import test from "node:test";
import assert from "node:assert/strict";
import {
  interpolatePolarSpeed,
  optimalDownwindAngle
} from "../src/domain/sailing/polars.js";

const windSpeeds = [6, 10, 15];
const polarTable = {
  42: [4, 5, 6],
  60: [5, 6, 7],
  120: [5.2, 6.2, 7.2],
  150: [4.8, 5.8, 6.8]
};

test("returns zero in no-sail zone", () => {
  assert.equal(
    interpolatePolarSpeed({
      polarTable,
      windSpeeds,
      trueWindAngle: 20,
      trueWindSpeed: 10
    }),
    0
  );
});

test("returns exact table value", () => {
  assert.equal(
    interpolatePolarSpeed({
      polarTable,
      windSpeeds,
      trueWindAngle: 60,
      trueWindSpeed: 10
    }),
    6
  );
});

test("interpolates between angle and wind bins", () => {
  const result = interpolatePolarSpeed({
    polarTable,
    windSpeeds,
    trueWindAngle: 51,
    trueWindSpeed: 8
  });

  assert.ok(result > 4 && result < 6);
});

test("finds an available downwind optimum", () => {
  const result = optimalDownwindAngle({
    polarTable,
    windSpeeds,
    trueWindSpeed: 10
  });

  assert.ok([120, 150].includes(result));
});
