import test from "node:test";
import assert from "node:assert/strict";
import {
  velocityMadeGood,
  upwindVmg,
  downwindVmg
} from "../src/domain/sailing/vmg.js";

test("VMG equals speed when heading directly toward target", () => {
  assert.equal(
    velocityMadeGood({
      boatSpeed: 6,
      boatHeading: 90,
      targetBearing: 90
    }),
    6
  );
});

test("VMG is near zero when perpendicular to target", () => {
  const result = velocityMadeGood({
    boatSpeed: 6,
    boatHeading: 90,
    targetBearing: 0
  });

  assert.ok(Math.abs(result) < 1e-10);
});

test("upwind VMG is positive at 45 degrees", () => {
  assert.ok(
    upwindVmg({
      boatSpeed: 6,
      trueWindAngle: 45
    }) > 4
  );
});

test("downwind VMG is positive at 150 degrees", () => {
  assert.ok(
    downwindVmg({
      boatSpeed: 6,
      trueWindAngle: 150
    }) > 5
  );
});
