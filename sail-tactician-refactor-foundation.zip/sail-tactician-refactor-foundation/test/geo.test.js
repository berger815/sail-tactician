import test from "node:test";
import assert from "node:assert/strict";
import {
  distanceNauticalMiles,
  initialBearingDegrees,
  midpoint
} from "../src/domain/navigation/geo.js";

test("distance between identical points is zero", () => {
  const point = { lat: 33.8, lon: -78.7 };
  assert.equal(distanceNauticalMiles(point, point), 0);
});

test("northward bearing is approximately zero", () => {
  const bearing = initialBearingDegrees(
    { lat: 33, lon: -79 },
    { lat: 34, lon: -79 }
  );

  assert.ok(bearing < 0.001 || bearing > 359.999);
});

test("midpoint falls between coordinates", () => {
  const result = midpoint(
    { lat: 33, lon: -79 },
    { lat: 35, lon: -77 }
  );

  assert.ok(result.lat > 33 && result.lat < 35);
  assert.ok(result.lon > -79 && result.lon < -77);
});
