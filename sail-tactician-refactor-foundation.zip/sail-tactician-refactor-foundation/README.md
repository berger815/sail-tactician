# Sail Tactician — Refactor Foundation

This package is the first architecture step for `berger815/sail-tactician`.

It intentionally does **not** modify the existing standalone HTML application.
The purpose is to establish a modular structure and extract pure, testable sailing/navigation logic before touching UI behavior.

## Included

- `src/domain/navigation/angles.js`
- `src/domain/navigation/geo.js`
- `src/domain/sailing/legs.js`
- `src/domain/sailing/polars.js`
- `src/domain/sailing/vmg.js`
- unit tests using Node's built-in test runner
- architecture and migration documentation

## Run tests

Requires Node.js 18 or newer.

```bash
npm test
```

## Recommended GitHub upload

1. Create a branch named `agent/architecture-refactor-foundation`.
2. Upload this package at the repository root.
3. Do not delete or rename the current working HTML file.
4. Open a draft pull request against `main`.

## Next migration step

After these pure functions are reviewed and tested, selectively replace duplicated calculations inside the existing app with imports from these modules. Do that one subsystem at a time.
