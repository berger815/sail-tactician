# Migration Plan

## Phase 1 — Pure domain foundation

Extract and test:

- heading normalization and angle differences
- bearing and distance
- leg classification
- polar interpolation
- optimal VMG angles
- VMG calculations

Status: included in this package.

## Phase 2 — Compatibility adapter

Create adapters that translate current globals such as `NAV`, `WIND`, and `CRS` into explicit domain function inputs.

Example:

```js
const leg = classifyLeg({
  trueWindDirection: WIND.twd,
  markBearing: legBearing()
});
```

No user-visible behavior should change.

## Phase 3 — Replay regression tests

Store representative telemetry fixtures and assert:

- detected leg type
- target headings
- VMG
- tack recommendations
- mark progression decisions

This protects sailing behavior during later refactors.

## Phase 4 — Services

Move side effects behind explicit service interfaces:

- GPS
- orientation
- weather
- storage
- telemetry
- file import/export

## Phase 5 — State

Replace direct global mutation with actions and selectors.

Do not begin with a complex state library. A small observable store is sufficient.

## Phase 6 — Features

Separate:

- Plan
- Start
- Race
- Replay
- Polar Forge
- Setup

Each feature owns its UI and orchestration but consumes shared domain functions.
