# Target Architecture

## Current state

The application is a large standalone HTML file containing:

- presentation
- DOM event wiring
- mutable application state
- GPS and orientation sensors
- filtering
- weather retrieval
- course setup
- race logic
- routing
- polar interpolation
- telemetry
- replay
- persistence

This structure supported rapid experimentation but now creates coupling and regression risk.

## Architectural rule

Business and sailing calculations must be independent from:

- DOM access
- browser APIs
- global state
- local storage
- network calls
- notifications

Pure domain functions receive values and return values.

## Target layers

```text
src/
├── app/          orchestration and application lifecycle
├── state/        store, actions, selectors
├── domain/       pure deterministic calculations
├── services/     GPS, sensors, weather, storage, telemetry
├── features/     plan, start, race, replay, polar forge, setup
└── ui/           rendering, controls, canvas, modals
```

## Dependency direction

```text
UI / Features
     ↓
Application orchestration
     ↓
Domain logic

Services → Application orchestration
```

The domain layer must not import from UI, services, or global application state.

## Refactor strategy

1. Add pure modules and tests.
2. Keep the existing application operational.
3. Replace one calculation family at a time.
4. Add replay-based regression fixtures.
5. Move sensor and persistence behavior behind services.
6. Introduce a central store only after calculation boundaries are stable.
7. Split feature UI after state and domain boundaries are proven.

## Non-goals for this phase

- React conversion
- UI redesign
- cloud backend
- rewriting the whole application
- changing live race behavior
