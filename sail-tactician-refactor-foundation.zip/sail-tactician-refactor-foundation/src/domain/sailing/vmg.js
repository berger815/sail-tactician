import { degreesToRadians } from "../navigation/angles.js";

/**
 * Velocity made good along a target bearing.
 */
export function velocityMadeGood({
  boatSpeed,
  boatHeading,
  targetBearing
}) {
  if (
    !Number.isFinite(boatSpeed) ||
    !Number.isFinite(boatHeading) ||
    !Number.isFinite(targetBearing)
  ) {
    throw new TypeError(
      "boatSpeed, boatHeading, and targetBearing must be finite numbers"
    );
  }

  return boatSpeed * Math.cos(
    degreesToRadians(boatHeading - targetBearing)
  );
}

/**
 * VMG toward the wind for upwind analysis.
 * A positive result means progress toward the wind source.
 */
export function upwindVmg({ boatSpeed, trueWindAngle }) {
  if (!Number.isFinite(boatSpeed) || !Number.isFinite(trueWindAngle)) {
    throw new TypeError(
      "boatSpeed and trueWindAngle must be finite numbers"
    );
  }

  return boatSpeed * Math.cos(degreesToRadians(Math.abs(trueWindAngle)));
}

/**
 * VMG directly downwind.
 */
export function downwindVmg({ boatSpeed, trueWindAngle }) {
  if (!Number.isFinite(boatSpeed) || !Number.isFinite(trueWindAngle)) {
    throw new TypeError(
      "boatSpeed and trueWindAngle must be finite numbers"
    );
  }

  return boatSpeed * Math.cos(
    degreesToRadians(180 - Math.abs(trueWindAngle))
  );
}
