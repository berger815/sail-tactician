function validatePolarTable(polarTable) {
  if (!polarTable || typeof polarTable !== "object") {
    throw new TypeError("polarTable must be an object");
  }
}

function findBracket(values, target) {
  if (target <= values[0]) return { lo: 0, hi: 0, ratio: 0 };

  const last = values.length - 1;
  if (target >= values[last]) {
    return { lo: last, hi: last, ratio: 0 };
  }

  for (let index = 0; index < last; index += 1) {
    const low = values[index];
    const high = values[index + 1];

    if (target >= low && target <= high) {
      return {
        lo: index,
        hi: index + 1,
        ratio: (target - low) / (high - low)
      };
    }
  }

  throw new Error("unable to bracket target");
}

function interpolate(low, high, ratio) {
  return low + (high - low) * ratio;
}

/**
 * Interpolate boat speed from a polar table.
 *
 * `polarTable` format:
 * {
 *   42: [4.2, 5.1, 5.8],
 *   60: [5.0, 6.0, 6.8]
 * }
 *
 * The arrays correspond to `windSpeeds`.
 */
export function interpolatePolarSpeed({
  polarTable,
  windSpeeds,
  trueWindAngle,
  trueWindSpeed,
  minimumSailingAngle = 32,
  maximumSailingAngle = 175
}) {
  validatePolarTable(polarTable);

  if (!Array.isArray(windSpeeds) || windSpeeds.length === 0) {
    throw new TypeError("windSpeeds must be a non-empty array");
  }

  if (
    !Number.isFinite(trueWindAngle) ||
    !Number.isFinite(trueWindSpeed)
  ) {
    throw new TypeError(
      "trueWindAngle and trueWindSpeed must be finite numbers"
    );
  }

  const angle = Math.abs(trueWindAngle);

  if (
    angle < minimumSailingAngle ||
    angle > maximumSailingAngle
  ) {
    return 0;
  }

  const angles = Object.keys(polarTable)
    .map(Number)
    .filter(Number.isFinite)
    .sort((a, b) => a - b);

  if (angles.length === 0) return 0;

  const angleBracket = findBracket(angles, angle);
  const windBracket = findBracket(windSpeeds, trueWindSpeed);

  const speedAt = (angleValue, windIndex) => {
    const row = polarTable[angleValue];
    const value = row?.[windIndex];
    return Number.isFinite(value) ? value : 0;
  };

  const lowAngleLowWind = speedAt(
    angles[angleBracket.lo],
    windBracket.lo
  );
  const lowAngleHighWind = speedAt(
    angles[angleBracket.lo],
    windBracket.hi
  );
  const highAngleLowWind = speedAt(
    angles[angleBracket.hi],
    windBracket.lo
  );
  const highAngleHighWind = speedAt(
    angles[angleBracket.hi],
    windBracket.hi
  );

  const lowAngleSpeed = interpolate(
    lowAngleLowWind,
    lowAngleHighWind,
    windBracket.ratio
  );
  const highAngleSpeed = interpolate(
    highAngleLowWind,
    highAngleHighWind,
    windBracket.ratio
  );

  return Math.max(
    0,
    interpolate(
      lowAngleSpeed,
      highAngleSpeed,
      angleBracket.ratio
    )
  );
}

/**
 * Find the TWA producing maximum downwind VMG.
 */
export function optimalDownwindAngle({
  polarTable,
  windSpeeds,
  trueWindSpeed,
  candidateAngles
}) {
  const angles = candidateAngles ??
    Object.keys(polarTable)
      .map(Number)
      .filter(angle => Number.isFinite(angle) && angle >= 90)
      .sort((a, b) => a - b);

  if (angles.length === 0) return null;

  let bestAngle = null;
  let bestVmg = -Infinity;

  for (const angle of angles) {
    const speed = interpolatePolarSpeed({
      polarTable,
      windSpeeds,
      trueWindAngle: angle,
      trueWindSpeed
    });

    const vmg = speed * Math.cos((180 - angle) * Math.PI / 180);

    if (vmg > bestVmg) {
      bestVmg = vmg;
      bestAngle = angle;
    }
  }

  return bestAngle;
}
