import { absoluteAngleDifference } from "../navigation/angles.js";

/**
 * Classify a race leg using true wind direction and mark bearing.
 *
 * Wind direction is the direction the wind is coming from.
 */
export function classifyLeg({
  trueWindDirection,
  markBearing,
  upwindThreshold = 70,
  downwindThreshold = 110
}) {
  if (
    !Number.isFinite(trueWindDirection) ||
    !Number.isFinite(markBearing)
  ) {
    return "unknown";
  }

  if (upwindThreshold >= downwindThreshold) {
    throw new RangeError(
      "upwindThreshold must be less than downwindThreshold"
    );
  }

  const angle = absoluteAngleDifference(
    trueWindDirection,
    markBearing
  );

  if (angle < upwindThreshold) return "upwind";
  if (angle > downwindThreshold) return "downwind";
  return "reach";
}
