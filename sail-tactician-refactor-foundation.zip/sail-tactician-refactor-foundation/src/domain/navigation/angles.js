/**
 * Normalize an angle to the range [0, 360).
 */
export function normalizeDegrees(value) {
  if (!Number.isFinite(value)) {
    throw new TypeError("value must be a finite number");
  }

  return ((value % 360) + 360) % 360;
}

/**
 * Return the shortest signed angular difference from `from` to `to`.
 * Result is in the range [-180, 180).
 */
export function angleDifference(from, to) {
  if (!Number.isFinite(from) || !Number.isFinite(to)) {
    throw new TypeError("from and to must be finite numbers");
  }

  return ((to - from + 540) % 360) - 180;
}

/**
 * Return the smallest unsigned difference between two headings.
 */
export function absoluteAngleDifference(a, b) {
  return Math.abs(angleDifference(a, b));
}

/**
 * Convert degrees to radians.
 */
export function degreesToRadians(value) {
  if (!Number.isFinite(value)) {
    throw new TypeError("value must be a finite number");
  }

  return value * Math.PI / 180;
}

/**
 * Convert radians to degrees.
 */
export function radiansToDegrees(value) {
  if (!Number.isFinite(value)) {
    throw new TypeError("value must be a finite number");
  }

  return value * 180 / Math.PI;
}
