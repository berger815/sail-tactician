import {
  degreesToRadians,
  normalizeDegrees,
  radiansToDegrees
} from "./angles.js";

const EARTH_RADIUS_METERS = 6_371_008.8;
const METERS_PER_NAUTICAL_MILE = 1852;

function validatePoint(point, name) {
  if (
    !point ||
    !Number.isFinite(point.lat) ||
    !Number.isFinite(point.lon)
  ) {
    throw new TypeError(`${name} must contain finite lat and lon values`);
  }
}

/**
 * Great-circle distance between two coordinates in nautical miles.
 */
export function distanceNauticalMiles(from, to) {
  validatePoint(from, "from");
  validatePoint(to, "to");

  const lat1 = degreesToRadians(from.lat);
  const lat2 = degreesToRadians(to.lat);
  const deltaLat = degreesToRadians(to.lat - from.lat);
  const deltaLon = degreesToRadians(to.lon - from.lon);

  const a =
    Math.sin(deltaLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon / 2) ** 2;

  const centralAngle = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return (EARTH_RADIUS_METERS * centralAngle) / METERS_PER_NAUTICAL_MILE;
}

/**
 * Initial great-circle bearing from one coordinate to another.
 */
export function initialBearingDegrees(from, to) {
  validatePoint(from, "from");
  validatePoint(to, "to");

  const lat1 = degreesToRadians(from.lat);
  const lat2 = degreesToRadians(to.lat);
  const deltaLon = degreesToRadians(to.lon - from.lon);

  const y = Math.sin(deltaLon) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLon);

  return normalizeDegrees(radiansToDegrees(Math.atan2(y, x)));
}

/**
 * Geographic midpoint between two coordinates.
 */
export function midpoint(from, to) {
  validatePoint(from, "from");
  validatePoint(to, "to");

  const lat1 = degreesToRadians(from.lat);
  const lon1 = degreesToRadians(from.lon);
  const lat2 = degreesToRadians(to.lat);
  const deltaLon = degreesToRadians(to.lon - from.lon);

  const bx = Math.cos(lat2) * Math.cos(deltaLon);
  const by = Math.cos(lat2) * Math.sin(deltaLon);

  const lat3 = Math.atan2(
    Math.sin(lat1) + Math.sin(lat2),
    Math.sqrt((Math.cos(lat1) + bx) ** 2 + by ** 2)
  );
  const lon3 = lon1 + Math.atan2(by, Math.cos(lat1) + bx);

  return {
    lat: radiansToDegrees(lat3),
    lon: normalizeLongitude(radiansToDegrees(lon3))
  };
}

function normalizeLongitude(value) {
  return ((value + 540) % 360) - 180;
}
